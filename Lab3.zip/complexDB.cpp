#include "complexDB.h"
#include "complex.h"
#include<cassert>
#include<iostream>
#include<fstream>
using namespace std;
complexDB::complexDB(int num)
{   len = 0;
    if(num<0)
        max = 100;
    else
        max = num;
    ptr = new complexType[max];
    assert(ptr!=NULL);
}

void complexDB::insert_comp(const complexType &comp)
{   
    if(len<max)
    {
       ptr[len++]= comp;
    }
    else
        cout<<"Array is full."<<endl;
}
void complexDB::delete_comp(complexType &comp)
{   int loc,ct=0;
    for(int i=0;i<len;i++)
    {
        if(ptr[i]==comp)
        {   
            ct++;
            cout<<"Found and Deleted"<<endl;
            loc = i;       
            for(int i=loc;i<len-1;i++)
                ptr[i]=ptr[i+1];
            len--;
        }
    }
    if(ct==0)
        cout<<"Number not found.."<<endl;
  
            
}
void complexDB::display(ostream &out)
{
    out<<"Here is the list.."<<endl;
    for(int i=0;i<len;i++)
        out<<ptr[i]<<endl;
}

void complexDB::save_to_file()
{
     //open output file
    ofstream fout;
    fout.open("lab3complex.txt");
    if(fout.fail())
    {
        cout<<"Couldn't open output file.";
    }
    display(fout);
    //close output file
    cout<<"Saved successfully!";
    fout.close();
}
void display_menu(int &ch)
{
    cout<<"Press 0 to Insert from file."<<endl;
    cout<<"Press 1 to Insert."<<endl;
    cout<<"Press 2 to Delete."<<endl;
    cout<<"Press 3 to Display."<<endl;
    cout<<"Press 4 to Store."<<endl;
    cout<<"Press 9 to Exit."<<endl;
    cin>>ch;
}
