#include "complex.h"
#include<fstream>
#include<iostream>
#include<string>
#include<sstream>
using namespace std;

//Updates the number of lines in the text file
void num_line(ifstream& fin, int& Num)
{
    string line;
    while (getline(fin, line))
        Num++;
}

//constructor with default parameter
complexType::complexType(double rl,double im)
{
real=rl;
imag=im;
}

//Read from input file if it is a complex number, 
//store it to the member variables 
int complexType::read_complex(ifstream& fin)
{
    string line;
    int ct=0;
    if (!fin.eof())
    {
      getline(fin, line);
      ct = set_complex(line);
    }
    return ct;
}

int complexType::set_complex(string line)
{
    double rl,im;
    char s='\0';
    int ct=0;
    if(isdigit(line[0]) == true || line[0]=='+'||line[0]=='-') 
      {
      ct=1;
      stringstream(line)>>rl>>s>>im;
     //To accomodate all forms of complex numbers such as, a+bi, a, bi
      if(s=='i')
      {  
         im=rl;
         rl=0;
      }
      else if(s=='-')
      {
          im=-im;
      }
      else if(s=='\0')
          im=0;
      //assign it to class members variables
      real=rl;
      imag=im;
      }
    return ct;
}
istream& operator>>(istream &is, complexType &input)
{   
    string line;
    is>>line;
    input.set_complex(line);
    return is;
}
ostream& operator<< (ostream &os, complexType& comp)
{   if(comp.imag>=0)
        os<<comp.real<<"+"<<comp.imag<<"i";
    else
        os<<comp.real<<comp.imag<<"i";
}
bool complexType::operator==(const complexType &comp)const
{
   return (real==comp.real && imag == comp.imag);    
}

