/* 
 * File:   complexDB.h
 * Author: thasleem
 *
 * Created on September 30, 2019, 7:46 PM
 */

#ifndef COMPLEXDB_H
#define	COMPLEXDB_H
#include "complex.h"
class complexDB
{
    
public:
    complexDB(int = 100);//constructor with default parameter
    void insert_comp(const complexType &);
    void delete_comp(complexType &);
    void display(ostream &);
    void save_to_file();
   
private:
    int max;
    int len;
    complexType* ptr;
};
void display_menu(int &ch);


#endif	/* COMPLEXDB_H */

