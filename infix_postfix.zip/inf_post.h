/* 
 * File:   inf_post.h
 * Author: thasleem
 *
 * Created on November 21, 2019, 8:37 PM
 */
#ifndef INF_POST_H
#define	INF_POST_H
#include <string>
#include<iostream>
using namespace std;
class inf_post
{
public:
    inf_post();
    int precedence(char); 
    void getInfix();
    void showInfix();
    void convertToPostfix();
    bool isOperand(char);
    bool isOperator(char);
    void showPostfix();
    void reset();
private:
    string infix;
    string postfix;
};

#endif	/* INF_POST_H */

