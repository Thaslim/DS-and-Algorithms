/* 
 * File:   stack.h
 * Author: thasleem
 *
 * Created on November 2, 2019, 7:19 AM
 */
#ifndef STACK_H
#define	STACK_H
#include<iostream>
#include<string>
using namespace std;

template<class type>
class node
{
public:
    type data;
    node<type> *next;
};

template<class type>
class linked_stack
{
public:
    linked_stack();
    ~linked_stack();
    void push(const type& item);
    void pop();
    type top()const;
    bool isempty()const;
    int size();
    node<type> * stacktop;
    int count;
};
#include "stack_imp.cpp"
#endif	/* STACK_H */



