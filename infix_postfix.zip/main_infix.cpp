/* 
 * File:   main.cpp
 * Author: thasleem
 *
 * Created on October 17, 2019, 6:26 AM
 */
#include<iostream>
#include<string>
#include "inf_post.h"
using namespace std;
int main()
{
    char ch;
    inf_post input;
    do
    {
    input.getInfix();
    input.showInfix();
    input.convertToPostfix();
    input.showPostfix();
    cout<<"\nDo you want to try again? :";
    cin>>ch;
    input.reset();
    }while(ch=='y'||ch=='Y');
    return 0;
}

