#include "inf_post.h"
#include "stack.h"
#include <string>
#include<iostream>
using namespace std;

inf_post::inf_post()
{
   infix="";
    postfix="";
}

void inf_post::reset()
{
       infix="";
    postfix="";
}
int inf_post::precedence(char inp) 
{ 
    switch (inp) 
    { 
    case '+': 
    case '-': 
        return 1; 
    case '*': 
    case '%': 
    case '/': 
        return 2; 
    case '^': 
        return 3; 
    case '(': 
        return 4; 
    default:
            return -1;
    } 
}

bool inf_post::isOperator(char inp) 
{ 
    switch (inp)
    { 
    case '+': 
    case '-': 
    case '*': 
    case '^': 
    case '%': 
    case '/':  
    case '(': 
        return true; 
    default:
        return false;
    }
} 

void inf_post::getInfix()
{
    cout<<"Enter an infix expression :";
    cin>>infix;
}

void inf_post::showInfix()
{
    cout<<"\nyou entered:";
    cout<<infix;
}

void inf_post::showPostfix()
{
    cout<<"\nPostfix expression:";
    cout<<postfix;
}

bool inf_post::isOperand(char input) 
{ 
    if (input >= 65 && input <= 90 || input >= 97 && input <= 122) 
        return true; 
 return false; 
} 

void inf_post::convertToPostfix()
{
    linked_stack<char> s;
    char c='\0';
    int i = 0; 
    while (infix[i] != '\0') { 
  
        // if i/p an operand 
        if (isOperand(infix[i]))
        { 
            postfix+= infix[i];
        } 
  
        // if character is an operator, push 
        else if (isOperator(infix[i]))
        { 
            if (s.isempty() || precedence(infix[i]) > precedence(s.top())) 
            {
                s.push(infix[i]);
                cout<<"\nhere 3:"<<s.top();
            }
            else if(precedence(infix[i]) == precedence(s.top()))
            {
                s.push(infix[i]);
            }
            else
            { 
                while (!s.isempty() && s.top() != '('&& precedence(infix[i]) <= precedence(s.top()))
                { 
                    c = s.top();
                    postfix+= c; 
                    s.pop(); 
                } 
                s.push(infix[i]); 
            } 
        } 
  
        // condition for '(' bracket 
        else if (infix[i] == ')') 
        { 
            while (s.top() != '(')
            {                
                c = s.top();
                postfix+= c; 
                s.pop(); 
                // if opening bracket not present 
                if (s.isempty())
                { 
                    printf("Wrong input\n"); 
                    exit(1); 
                } 
            } 
  
            // pop ')'. 
            s.pop(); 
        } 
        i++; 
    } 
  
    // pop all the left out operators
    while (!s.isempty())
    { 
        if (s.top() == '(') { 
            printf("\n Wrong input\n"); 
            exit(1); 
        } 
        c = s.top();
        postfix+= c;
        s.pop(); 
    } 
}
