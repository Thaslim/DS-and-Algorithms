/* 
 * File:   complex.h
 * Author: thasleem
 *
 * Created on September 13, 2019, 4:31 PM
 */

#ifndef COMPLEX_H
#define	COMPLEX_H
#include<fstream>
using namespace std;
class complexType
{
    //operator overloading for insertion and extraction
    friend istream& operator>> (istream&, complexType&);
    friend ostream& operator<< (ostream&, complexType&);
    
public:
    //Constructor with default parameters
    complexType(double =0,double =0);
    int read_complex(ifstream&);
    int set_complex(string);
    //overload the operator ==
    bool operator==(const complexType &)const;
    bool operator>(const complexType &)const;
           
private:
    double real;
    double imag;
};
//Get the number of lines in the input file
void num_line(ifstream&, int&);

#endif	/* COMPLEX_H */

