/* 
 * File:   main.cpp
 * Author: thasleem
 *
 * Created on September 13, 2019, 4:30 PM
 */
#include <iostream>
#include <fstream>
#include "complex.h"
#include "complexDB.h"
using namespace std;
int main()
{
    ifstream fin;
    int line_ct=0,ch,num;
    char ans,res;
    //create object to insert first 3 elements from file.
    complexType inp;
    complexDB thas(20);
    //Open complex.txt file
    fin.open("complex.txt");
    if(fin.fail())
    {
        cout<<"Couldn't open input file.";
    }
    //Get the number of lines in the file
    num_line(fin,line_ct);
    //close the input file
    fin.close();

    display_menu(ch);
    do
    {
    switch(ch)
    {
        case 0: cout<<"Number of lines in the text file."<<line_ct<<endl;
                    //Reopen the input file
                fin.open("complex.txt");
                if(fin.fail())
                {
                    cout<<"Couldn't open input file.";
                }
                cout<<"Number of complex items to insert : ";
                cin>>num;
                if(num<line_ct)
                {
                    int count=0;
                    while(count<num)
                    {
                       if(inp.read_complex(fin)==1)
                       {
                           count++;
                           thas.insert_comp(inp);
                       }
                    }
                }
                fin.close();
                break;
   
        case 1: do
                {
                cout<<"Enter a complex number : ";
                cin>>inp;
                thas.insert_comp(inp);
                cout<<"Want to insert again ? ";
                cin>>res;
                }while(res == 'y'||res == 'Y');
                break;
        case 2: do
                {
                cout<<"Enter a complex number to be deleted : ";
                cin>>inp;
                thas.delete_comp(inp);
                cout<<"Want to delete again ? ";
                cin>>res;
                }while(res == 'y'||res == 'Y');
                break;
        case 3: thas.display(cout);
                break;
        case 4: thas.save_to_file();
                break;
        case 5: thas.bubble_sort();
                cout<<"After bubble sort..";
                thas.display(cout);
                break;
        case 6: thas.insertion_sort();
                cout<<"After insertion sort..";
                thas.display(cout);
                break;
        case 7: thas.selection_sort();
                cout<<"After selection sort..";
                thas.display(cout);
                break; 
        case 9: cout<<"Thank you!";
                break;
        default:cout<<"Invalid Entry." ;  
                 break;
    }
    cout<<"Want to choose another operation.?"<<endl;
    cin>>ans;
    if(ans=='y'||ans=='Y')
    {
        cout<<"Select operation.."<<endl;
        cin>>ch;
    }
    }while(ans=='y'||ans=='Y');
     
 }

   

