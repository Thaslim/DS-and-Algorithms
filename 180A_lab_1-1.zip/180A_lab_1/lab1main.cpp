/* 
 * File:   main.cpp
 * Author: thasleem
 *
 * Created on September 3, 2019, 4:59 PM
 */
#include<iostream>
#include "clockType.h"
using namespace std;
int main()
{
clockType c1(15, 45, 30), c2(3, 20);  // hour, min, sec
cout<<"Printing c1 :"<<endl;
cout << c1<<endl; 
cout<<"Printing c2 :"<<endl;
cout << c2<<endl;
cout<<"Printing c1+c2 :"<<endl;
cout << c1+c2<<endl;
c2 = c1+c1;
cout<<"Printing c2 =c1+c1 :"<<endl;
cout << c2<<endl;
}
