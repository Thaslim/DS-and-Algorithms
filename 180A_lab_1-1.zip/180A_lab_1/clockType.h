/* 
 * File:   clockType.h
 * Author: thasleem
 * Created on September 3, 2019, 5:00 PM
 */
//Header file for clocktype.h
#ifndef CLOCKTYPE_H
#define	CLOCKTYPE_H
#include<iostream>
using namespace std;
class clockType
{//function declaration for operator "<<"
    friend ostream& operator<<(ostream&, const clockType&);
public:
    //Constructor with default parameters
    clockType(int h=0,int m=0,int s=0);
    //function declaration for operator "+"
    clockType operator+(clockType& );
   
private:
    //Private function for incrementing hrs/mins/secs by 1.
    void incrmntHrs();
    void incrmntMins();
    void incrmntSecs();
    //member variables of class clocktype.
    int hr;
    int min;
    int sec;
  
};

#endif	/* CLOCKTYPE_H */

