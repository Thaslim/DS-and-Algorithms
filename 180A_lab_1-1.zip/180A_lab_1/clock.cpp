//Implementation file

#include "clockType.h"
#include<iostream>
using namespace std;
//definition of constructor
  clockType::clockType(int h, int m ,int s )
  {
      if(0<=h && h<=23)
          hr=h;
      else
          hr=0;
       if(0<=m && m<=59)
          min=m;
      else
          min=0;
      if(0<=s && s<=59)
          sec=s;
      else
          sec=0;
  }
  //definition of "+" operator overloading function 
  clockType clockType::operator +(clockType& clock2)
  {
      clockType clock3;
      
      clock3.hr=hr+clock2.hr;
      if(clock3.hr>23)
          clock3.hr=clock3.hr-24;
      
      clock3.min=min+clock2.min;
      if(clock3.min>59)
      {
          clock3.min=clock3.min-60;
          clock3.incrmntHrs();
      }
      
      clock3.sec=sec+clock2.sec;
      if(clock3.sec>59)
      {
         clock3.sec=clock3.sec-60;
         clock3.incrmntMins();
      }
      return clock3;
      
  }
    //Increments hours by one. resets to 0 if its greater than 23

  void clockType::incrmntHrs()
  {
      hr++;
      if(hr>23)
          hr=0;
  }
   //Increments mins by one. resets to 0 if its greater than 59 and 
  //then calls incrmntHrs()

  void clockType::incrmntMins()
  {
      min++;
      if(min>59)
      {
          min=0;
          incrmntHrs();
      }
  }
     //Increments secs by one. resets to 0 if its greater than 59.
     // then calls incrmntMins();

  void clockType::incrmntSecs()
  {
      sec++;
      if(sec>59)
      {
          sec=0;
          incrmntMins();
      }
  }    
    //definition of "<<" operator overloading function 

  ostream& operator<<(ostream& os,const clockType& clk)
  {
      os<<"Hours :"<<clk.hr<<" Mins :"<<clk.min<<" Secs :"<<clk.sec;
      return os;
  }