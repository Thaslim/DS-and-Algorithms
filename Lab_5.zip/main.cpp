/* 
 * File:   main.cpp
 * Author: thasleem
 *
 * Created on October 17, 2019, 6:26 AM
 */
#include<iostream>
#include<string>
#include "stock_link.h"
#include<fstream>
using namespace std;
int main()
{
    linked_list list;
    string filename,sym;
    int num,ch;
    char ans;
    display_menu(ch);
    do
    {
    switch(ch)
    {
        case 1: cout<<"Enter file name and number of lines to read  :";
                cin>>filename>>num;
                list.ins_from_file(filename,num);
                break;
        case 2: cout<<"Enter stock symbol,cost,no.of stocks :"<<endl; 
                if(list.insert(cin)==true)
                   cout<<"stock added"<<endl;               
                break;
        case 3: cout<<"Enter the symbol of the stock to delete :";
                cin>>sym; 
                if(list.delete_node(sym)==true)
                    cout<<"Node deleted"<<endl;
                else
                    cout<<"Could not delete"<<endl;
                break;
        case 4: cout<<"Here is the list.."<<endl;
                list.display_all();
                break;
       case 5: list.find_middle();
               break;  
        default:cout<<"Select a valid choice"<<endl;
               break;
            
    }
    cout<<"Want to choose another operation?"<<endl;
    cin>>ans;
    cout<<"Select a choice.";
    cin>>ch;
    }while(ans == 'y'||ans=='Y');
          
}

