/* 
 * File:   stock_link.h
 * Author: thasleem
 *
 * Created on October 17, 2019, 6:27 AM
 */
#include<iostream>
#include<string>
#include<fstream>
using namespace std;
#ifndef STOCK_LINK_H
#define	STOCK_LINK_H
class stock
{
       //operator overloading for insertion and extraction
    friend istream& operator>> (istream&, stock&);
    friend ostream& operator<< (ostream&, stock&);
public:
    string symbol;
    int cost;
    int num;   
    
};

class node
{ 
public:
    stock stk;
    node *next;
};

class linked_list
{
public:
    linked_list();
    ~linked_list();
    bool insert(istream &in);
    void ins_from_file(string,int);
    bool delete_node(string);
    void display_all();
    void find_middle();
    int len;
    node *head,*tail;
};
void display_menu(int &ch);
#endif	/* STOCK_LINK_H */

