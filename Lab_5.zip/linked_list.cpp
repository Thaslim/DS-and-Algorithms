#include<iostream>
#include<string>
#include "stock_link.h"
#include<fstream>
using namespace std;

istream& operator>> (istream& in, stock& s)
{
    in>>s.symbol>>s.cost>>s.num;  
    return in;
}

ostream& operator<< (ostream& os, stock& s)
{
    os<<s.symbol<<" "<<s.cost<<" "<<s.num;
    return os;
}
 
linked_list::linked_list()
{
    len = 0;
    head = NULL; 
    tail = NULL;
}

linked_list::~linked_list()
{
    node *temp;
    while(head!=NULL)
    {
        temp = head;
        head = head->next;
        delete temp;
    }
    tail = NULL;
    len = 0;
    cout<<"\nList deleted";
}
bool linked_list::insert(istream &in)
{
      node *csp = new node;
      in >> (csp->stk);
      csp->next = NULL; 
      if(head == NULL)
      {
        head = csp;
        tail = csp;
      }
      else
      {
        tail->next = csp;
        tail = csp;
      }
    
      len++;
      return true;
}

void linked_list::ins_from_file(string fname,int num)
{
    ifstream fin;
    int ct = 0;
    fin.open(fname);
    if (fin.fail())
        cout<<"Couldn't open input file.";
    while(!fin.eof()&& ct<num)
    {
        if(insert(fin)==true)
            ct++;
    }
    
    fin.close();
}
bool linked_list::delete_node(string del_st)
{
    node *curr,*prvcurr;
    if(head==NULL)
        cout<<"List is empty"<<endl;
    else
    {
        if(head->stk.symbol==del_st)
        {
            head = head->next;
            len--;
            if(head==NULL)
                tail=NULL;
            return true;
        }
        else
        {
            prvcurr=head;
            curr=head->next;
            while(curr!=NULL)
            {
                if(curr->stk.symbol==del_st)
                {
                    prvcurr->next = curr->next;
                    len--;
                    if(tail==curr)
                        tail=prvcurr;
                    delete curr;  
                    return true;
                }
                prvcurr=curr;
                curr=curr->next;
              
            }
                   
        }
        return false;
    }
}
void linked_list::display_all()
{
    node *curr;
    curr = head;
    int i = 1;
    while(curr!= NULL)
    {
        cout << i << ": " << curr->stk << endl;
        curr = curr->next;
        i++;
    }
}

void display_menu(int &ch)
{
    cout<<"Press 1 to Insert from file."<<endl;
    cout<<"Press 2 to Insert from console."<<endl;
    cout<<"Press 3 to Delete."<<endl;
    cout<<"Press 4 to Display."<<endl;
    cout<<"Press 5 to find middle."<<endl;
    cin>>ch;
}
void linked_list::find_middle()
{
    node *slow = head;
    node *fast = head;
 
    if (head!=NULL)
    {
        while (fast != NULL && fast->next != NULL)
        {
            fast = fast->next->next;
            slow = slow->next;
        }
        cout<<"The middle of the list is :"<<slow->stk<<endl;
    }
}
