#include<iostream>
#include<string>
#include "stock_dblink.h"
#include<fstream>
using namespace std;

istream& operator>> (istream& in, stock& s)
{
    in>>s.symbol>>s.cost>>s.num;  
    return in;
}

ostream& operator<< (ostream& os, stock& s)
{
    os<<s.symbol<<" "<<s.cost<<" "<<s.num;
    return os;
}
 
dblinked_list::dblinked_list()
{
    len = 0;
    head = NULL; 
    tail = NULL;
}

dblinked_list::~dblinked_list()
{
    NodeD *temp;
    while(head!=NULL)
    {
        temp = head;
        head = head->next;
        delete temp;
    }
    tail = NULL;
    len = 0;
    cout<<"\nList deleted";
}
   
bool dblinked_list::insert(istream &in)
{
      NodeD *csp = new NodeD;
      in >> *csp;
      csp->next = NULL; 
      csp->prev = NULL;
      if(head == NULL)
      {
        head = csp;
        tail = csp;
      }
      else
      {          
        csp->prev = tail;
        tail->next = csp;
        csp->next = NULL;
        tail = csp;
      }
    
      len++;
      return true;
}
//Updates the number of lines in the text file
void num_line(ifstream& fin, int& Num)
{
    string line;
    while (getline(fin, line))
        Num++;
}
void dblinked_list::ins_from_file(string fname,int num)
{
    ifstream fin;
    int ct = 0;
    fin.open(fname);
    if (fin.fail())
        cout<<"Couldn't open input file.";
    while(!fin.eof()&& ct<num)
    {
        if(insert(fin)==true)
            ct++;
    }
    
    fin.close();
}
bool dblinked_list::delete_node(string del_st)
{
    NodeD *curr,*prvcurr;
    bool found;
    if(head==NULL)
        cout<<"List is empty"<<endl;
    else
    {
        if(head->symbol==del_st)
        {
            curr = head;
            head = head->next;
            if(head!=NULL)
                head->prev = NULL;
            else
                tail = NULL;
            len--;
            delete curr;
            return true;
        }
        else
        {
            found = false;
            curr=head;
            while(curr!=NULL && !found)
                if(curr->symbol==del_st)
                    found = true;
                else
                    curr = curr->next; 
            if(curr->symbol==del_st)  
            { 
                prvcurr = curr->prev;
                prvcurr->next = curr->next;
                if(curr->next!=NULL)
                    curr->next->prev = prvcurr;
                if(curr==tail)
                    tail = prvcurr;
                len--;
                delete curr;  
                return true;
            }
                          
        }
                   
    }
        return false;
}
void dblinked_list::display_all(int ord)
{
    NodeD *curr;
    if(ord ==1)
    {
    curr = head;
    int i = 1;
    while(curr!= NULL)
    {
        cout << i << ": " << *curr << endl;
        curr = curr->next;
        i++;
    }
    }
    else if(ord==2)
    {
        curr = tail;
        int i = 1;
        while(curr!= NULL)
        {
        cout << i << ": " << *curr << endl;
        curr = curr->prev;
        i++;
        }
    } 
        
}

void display_menu(int &ch)
{
    cout<<"Press 1 to Insert from file."<<endl;
    cout<<"Press 2 to Insert from console."<<endl;
    cout<<"Press 3 to Delete."<<endl;
    cout<<"Press 4 to Display."<<endl;
    cout<<"Press 5 to find middle."<<endl;
    cin>>ch;
}
void dblinked_list::find_middle()
{
    NodeD *slow = head;
    NodeD *fast = head;
 
    if (head!=NULL)
    {
        while (fast != NULL && fast->next != NULL)
        {
            fast = fast->next->next;
            slow = slow->next;
        }
        cout<<"The middle of the list is :"<<*slow<<endl;
    }
}
