/* 
 * File:   stock_link.h
 * Author: thasleem
 *
 * Created on October 17, 2019, 6:27 AM
 */
#include<iostream>
#include<string>
#include<fstream>

using namespace std;
#ifndef STOCK_DBLINK_H
#define	STOCK_DBLINK_H
class stock
{
       //operator overloading for insertion and extraction
    friend istream& operator>> (istream&, stock&);
    friend ostream& operator<< (ostream&, stock&);
public:
    string symbol;
    int cost;
    int num;   
    
};

class NodeD : public stock
{
public:
    NodeD *prev;
    NodeD *next;
};

class dblinked_list
{
public:
    dblinked_list();
    ~dblinked_list();
    bool insert(istream &);
    void ins_from_file(string,int);
    bool delete_node(string);
    void display_all(int);
    void find_middle();
    int len;
    NodeD *head,*tail;
};
void display_menu(int &ch);
void num_line(ifstream& fin, int& Num);
#endif	/* STOCK_LINK_H */

