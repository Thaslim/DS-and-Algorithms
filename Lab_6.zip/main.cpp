/* 
 * File:   main.cpp
 * Author: thasleem
 *
 * Created on October 17, 2019, 6:26 AM
 */
#include<iostream>
#include<string>
#include "stock_dblink.h"
#include<fstream>
using namespace std;
int main()
{
    dblinked_list dlist;
    string filename,sym;
    int num,ch,order,ct = 0;
    char ans;
    ifstream fin;
    display_menu(ch);
    do
    {
    switch(ch)
    {
        case 1: cout<<"Enter file name:";
                cin>>filename;
                fin.open(filename);
                if (fin.fail())
                    cout<<"Couldn't open input file.";
                num_line(fin,ct);
                fin.close();
                cout<<"\nThe number of entries in the file : "<<ct;
                cout<<"\nEnter the number of entries to load :";
                cin>>num;
                dlist.ins_from_file(filename,num);
                break;
        case 2: cout<<"Enter stock symbol,cost,no.of stocks :"<<endl; 
                if(dlist.insert(cin)==true)
                   cout<<"stock added"<<endl;               
                break;
        case 3: cout<<"Enter the symbol of the stock to delete :";
                cin>>sym; 
                if(dlist.delete_node(sym)==true)
                    cout<<"Node deleted"<<endl;
                else
                    cout<<"Could not delete"<<endl;
                break;
        case 4: cout<<"Press 1 to print forward or 2 to print in reverse : ";
                cin>>order;
                cout<<"Here is the list.."<<endl;
                dlist.display_all(order);
                break;
        case 5: dlist.find_middle();
               break;  
        default:cout<<"Select a valid choice"<<endl;
               break;
            
    }
    cout<<"Want to choose another operation?"<<endl;
    cin>>ans;
    cout<<"Select a choice.";
    cin>>ch;
    }while(ans == 'y'||ans=='Y');
          
}

