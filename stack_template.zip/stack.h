/* 
 * File:   stack.h
 * Author: thasleem
 *
 * Created on November 2, 2019, 7:19 AM
 */
#ifndef STACK_H
#define	STACK_H

#include<iostream>
#include<string>
using namespace std;

class stock
{
    //operator overloading for insertion and extraction
    //friend istream& operator>> (istream&, stock&);
    friend istream& operator>> (istream& in, stock& s)
    {
    in>>s.symbol>>s.cost>>s.num;  
    return in;
    }
   // friend ostream& operator<< (ostream&, stock&);
    friend ostream& operator<< (ostream& os, stock& s)
    {
    os<<s.symbol<<" "<<s.cost<<" "<<s.num;
    return os;
    }
public:
    string symbol;
    int cost;
    int num;   
    
};

template<class type>
class node
{
public:
    type data;
    node<type> *next;
};

template<class type>
class linked_stack
{
public:
    linked_stack();
    ~linked_stack();
    void push(const type& item);
    void pop();
    type top()const;
    bool isempty()const;
    int size();
    node<type> * stacktop;
    int count;
};
#include "stack_imp.cpp"
#endif	/* STACK_H */



