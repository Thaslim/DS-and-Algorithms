#include "stack.h"
#ifndef STACK_IMP
#define	STACK_IMP

template<class type>
linked_stack<type>::linked_stack()
{
    stacktop=NULL;
    count=0;
}

template<class type>
linked_stack<type>::~linked_stack()
{
 node<type> *temp;
 while(stacktop!=NULL)
 {
     temp = stacktop;
     stacktop = stacktop->next;
     delete temp;
     count--;
 }
}

template<class type>
void linked_stack<type>::push(const type& item)
{
    node<type>* curr = new node<type>;
    curr->data = item;
    curr->next = stacktop;
    stacktop = curr;  
    count++;
}

template<class type>
bool linked_stack<type>::isempty()const
{
    return (stacktop==0);
}

template<class type>
void linked_stack<type>::pop()
{
    node<type>* temp;
    if(stacktop!=NULL)
    {
          temp=stacktop;
          stacktop=stacktop->next;
          delete temp;  
          count--;
    }
    else
        cout<<"Stack is empty"<<endl;
  
}

template<class type>
type linked_stack<type>::top()const
{
    
    if(!isempty())
        return stacktop->data;
   
}

template<class type>
int linked_stack<type>::size()
{ 
    return count;
}

#endif