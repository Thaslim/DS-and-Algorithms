/* 
 * File:   main.cpp
 * Author: thasleem
 *
 * Created on October 17, 2019, 6:26 AM
 */
#include<iostream>
#include<string>
#include "stack.h"

using namespace std;
int main()
{
linked_stack<stock> mystock;
int choice,size;
stock tp,inp;
char ans,ch;
cout<<"1.push\n"
       << "2.pop\n"
        <<"3.top\n"
        <<"4.size\n"
        <<"5.Isempty\n";
do
{
cout<<"Enter a choice :";
cin>>choice;
switch(choice)
{

    case 1: do
            {
            cout<<"Enter a stock name,cost,share :"<<endl;
            cin>>inp;
            mystock.push(inp); 
            cout<<"Want to add another? : "<<endl;
            cin>>ans;
            }while(ans=='y'||ans=='Y');
            break;
    case 2: do
            {
            mystock.pop(); 
            cout<<"Want to pop another? : "<<endl;
            cin>>ans;
            }while(ans=='y'||ans=='Y');
            break;
    case 3: tp = mystock.top();
            cout<<"The top element of the stack is :"<<tp<<endl;
            break;
    case 4: size = mystock.size();
            cout<<"The size of the stack is :"<<size<<endl;
            break;
    case 5: if(mystock.isempty())
                cout<<"Stack is empty"<<endl;
            else
                cout<<"Stack is not empty"<<endl;
            break;
    default:
        cout<<"Invalid choice";  
}
 cout<<"Want to select another choice? :" <<endl;
 cin>>ch;
}while(ch=='y'||ch=='Y');
}

