/* 
 * File:   complex.h
 * Author: thasleem
 *
 * Created on September 13, 2019, 4:31 PM
 */

#ifndef COMPLEX_H
#define	COMPLEX_H
#include<fstream>
using namespace std;
class complexType
{
public:
    //Constructor with default parameters
    complexType(double =0,double =0);
    void display(ostream& );
    int set_complex(ifstream&);
    complexType operator+(const complexType&);
    
private:
    double real;
    double imag;
};
void num_line(ifstream&, int&);


#endif	/* COMPLEX_H */

