#include "complex.h"
#include<fstream>
#include<iostream>
#include<string>
#include<sstream>
using namespace std;

//Updates the number of lines in the text file
void num_line(ifstream& fin, int& Num)
{
    string line;
    while ( getline(fin, line))
        Num++;
}

//constructor with default parameter
complexType::complexType(double rl,double im)
{
real=rl;
imag=im;
}

//Read from input file if it is a complex number, 
//store it to the member variables 
int complexType::set_complex(ifstream& fin)
{
    string line;
    double rl,im;
    char s='\0';
    int ct=0;
    if (!fin.eof())
    {
      getline(fin, line);
      if (isdigit(line[0]) == true || line[0]=='+'||line[0]=='-') 
      {
      ct=1;
      stringstream(line)>>rl>>s>>im;
     //To accomodate all forms of complex numbers such as, a+bi, a, bi
      if(s=='i')
      {  
         im=rl;
         rl=0;
      }
      else if(s=='-')
      {
          im=-im;
      }
      else if(s=='\0')
          im=0;
      //assign it to class members variables
      real=rl;
      imag=im;
      }
    }
    return ct;
}
//Display stored complex numbers 
void complexType::display(ostream& out)
{
   if(imag>=0)
       out<<real<<"+"<<imag<<"i"<<endl;
   else
       out<<real<<imag<<"i"<<endl;
}

//add two complex variables and return the sum.
complexType complexType::operator+(const complexType& othr_complex)
{
    complexType temp;
    temp.real=real+othr_complex.real;
    temp.imag=imag+othr_complex.imag;
    return temp;
 }
