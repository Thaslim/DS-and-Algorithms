/* 
 * File:   main.cpp
 * Author: thasleem
 *
 * Created on September 13, 2019, 4:30 PM
 */
#include <iostream>
#include<fstream>
#include "complex.h"
using namespace std;
int main()
{
    ifstream fin;
    ofstream fout;
    int line_ct=0,count=0;
    //Open complex.txt file
    fin.open("complex.txt");
    if(fin.fail())
    {
        cout<<"Couldn't open input file.";
    }
    
    //Get the number of lines in the file
    num_line(fin,line_ct);
    cout<<"Number of lines in the text file."<<line_ct<<endl;
    
    //close the input file
    fin.close();
   
    //Create an array of complexType objects
    complexType obj[line_ct];
    complexType sum;
    
    //Reopen the input file
    fin.open("complex.txt");
    if(fin.fail())
    {
        cout<<"Couldn't open input file.";
    }
    
    //1.Read from input file,
    //2.store it to the class member variables 
    //3.display complex numbers
    //4.Add all the complex numbers
    for(int i=0;i<line_ct;i++)
    {
      if(obj[i].set_complex(fin)==1)
      {
          count++;
          obj[i].display(cout);
          sum=sum+obj[i];
      }
    }
    
    //Print the number of complex Numbers
    cout<<"Number of complex elements : "<<count<<endl;
    
   // output to the console
    cout<<"The sum of all complex numbers :";
    sum.display(cout);
   
    //open output file
    fout.open("complexobj.txt");
    if(fout.fail())
    {
        cout<<"Couldn't open output file.";
    }
    
   //Write the sum to file
    fout<<"The sum of all complex numbers :";
    sum.display(fout);
    //close output file
    fout.close();
}
