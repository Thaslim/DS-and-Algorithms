/* 
 * File:   stock_link.h
 * Author: thasleem
 *
 * Created on October 17, 2019, 6:27 AM
 */
#include<iostream>
#include<string>
#include<fstream>
using namespace std;
#ifndef STOCK_LINK_H
#define	STOCK_LINK_H
class stock
{
       //operator overloading for insertion and extraction
    friend istream& operator>> (istream&, stock&);
    friend ostream& operator<< (ostream&, stock&);
public:
    string symbol;
    int cost;
    int num;   
    
};

class node
{ 
public:
    stock stk;
    node *next;
};

class linked_list
{
public:
    linked_list();
    ~linked_list();
    node* insert(node*,stock);
    node* insert_at(node*,stock,int);
    node* ins_from_file(string,int);
    node* delete_node(node*,int);
    void display_all(node*,int);
    void search(node *,string);
    int find_loc(node*);
    void reverse(node*);
    int len;
    node *head,*tail;
};
void display_menu(int &ch);
#endif	/* STOCK_LINK_H */

