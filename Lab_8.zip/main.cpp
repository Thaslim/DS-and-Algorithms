/* 
 * File:   main.cpp
 * Author: thasleem
 *
 * Created on October 17, 2019, 6:26 AM
 */
#include<iostream>
#include<string>
#include "stock_link.h"
#include<fstream>
using namespace std;
int main()
{
    stock stk;
    linked_list list;
    string filename,text;
    int num,ch,sym;
    char ans;
    display_menu(ch);
    do
    {
    switch(ch)
    {
        case 1: cout<<"Enter file name and number of lines to read  :";
                cin>>filename>>num;
                list.head = list.ins_from_file(filename,num);
                break;
        case 2: cout<<"Enter stock symbol,cost,no.of stocks :"<<endl; 
                cin>>stk;
                list.head=list.insert(list.head,stk);
                cout<<"stock added"<<endl;               
                break;   
        case 3: cout<<"Enter the node to delete :";
                cin>>sym; 
                list.head = list.delete_node(list.head,sym);
                break;
        case 4: cout<<"Here is the list.."<<endl;
                list.display_all(list.head,1);
                break;
        case 5: list.reverse(list.head);
               cout<<"List is reversed!"<<endl;
               break;  
        case 6:cout<<"Enter a stock name to search :"<<endl;
               cin>>text;
               list.search(list.head,text);
               break;
        case 7: cout<<"Enter stock symbol,cost,no.of stocks :"<<endl; 
                cin>>stk;
                int pos;
                cout<<"enter the position :";
                cin>>pos;
                list.head=list.insert_at(list.head,stk,pos);
                cout<<"stock added"<<endl;               
                break;  
        default:cout<<"Select a valid choice"<<endl;
               break;
            
    }
    cout<<"Want to choose another operation?"<<endl;
    cin>>ans;
    cout<<"Select a choice.";
    cin>>ch;
    }while(ans == 'y'||ans=='Y');
          
}

