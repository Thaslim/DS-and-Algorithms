#include<iostream>
#include<string>
#include "stock_link.h"
#include<fstream>
using namespace std;

istream& operator>> (istream& in, stock& s)
{
    in>>s.symbol>>s.cost>>s.num;  
    return in;
}

ostream& operator<< (ostream& os, stock& s)
{
    os<<s.symbol<<" "<<s.cost<<" "<<s.num;
    return os;
}
 
linked_list::linked_list()
{
    len = 0;
    head = NULL; 
    tail = NULL;
}

linked_list::~linked_list()
{
    node *temp;
    while(head!=NULL)
    {
        temp = head;
        head = head->next;
        delete temp;
    }
    tail = NULL;
    len = 0;
    cout<<"\nList deleted";
}
node* linked_list::insert(node* curr,stock st)
{   
    if(curr == NULL || (curr->stk.symbol).compare(st.symbol) >= 0 ) 
    {
      node *ptr = new node;
      ptr->stk = st;
      ptr->next=curr;  
      return ptr;
      len++;
    }
    else 
    {
      curr->next = insert(curr->next, st); 
      return curr;
     
    }
}    

node* linked_list::insert_at(node* curr,stock st,int loc)
{   
  if(loc < 0||loc>len) {
        throw std::invalid_argument("Parameter 'position' must be greater or equal to 0.");
    }

    node * ptr = curr;
    int i = 1;
    for(;ptr && ptr->next && i < loc-1; ptr = ptr->next, ++i) {}
    
    node* newNode = new node;
    newNode->stk = st;
    newNode->next = ptr ? ptr->next : NULL;
    if(ptr) {
        ptr->next = newNode;
    }
    len++;
    return curr;
} 

node* linked_list::ins_from_file(string fname,int num)
{
    ifstream fin;
    stock fst;
    int ct = 0;
    node*temp = head;
    fin.open(fname);
    if (fin.fail())
        cout<<"Couldn't open input file.";
    while(!fin.eof()&& ct<num)
    {
        fin>>fst;
        temp = insert(temp,fst);
        ct++;
        len++;
      
    }
    fin.close();
    return temp;
}
node* linked_list::delete_node(node* curr, int k)
{
    if(k==1)
    {
        head = curr->next;
        delete(curr);
        cout<<"Node deleted"<<endl;
        return head;  
    }
    curr->next = delete_node(curr->next,k-1);  
    return curr;
}
void linked_list::display_all(node* curr,int i)
{
    if(curr!= NULL)
    {
        cout << i << ": " << curr->stk << endl;
        display_all(curr->next,i+1);
     
    }
}

void display_menu(int &ch)
{
    cout<<"Press 1 to Insert from file."<<endl;
    cout<<"Press 2 to Insert from console."<<endl;
    cout<<"Press 3 to Delete."<<endl;
    cout<<"Press 4 to Display."<<endl;
    cout<<"Press 5 Reverse."<<endl;
    cout<<"Press 6 to search item"<<endl;
    cout<<"Press 7 to insert at a position"<<endl;
    cin>>ch;
}

 void linked_list::reverse(node* curr)
 {
     if(curr->next==NULL)
     {
         head = curr;
         return;
     }
     reverse(curr->next);
     curr->next->next=curr;
     curr->next=NULL;
          
 }

 void linked_list::search(node *curr, string s_item)
 {
     if(curr==NULL)
         cout<<"Item not found"<<endl;
     else if(curr->stk.symbol==s_item)
     {
         cout<<"Item found at"<<find_loc(curr)<<endl;
     }
     else         
         search(curr->next,s_item);
 }
 
int linked_list::find_loc(node *curr)
{
    int loc=0;
    node* p =head;
    while(p!=NULL && p!=curr)
    {
       loc++;
       p=p->next;
    }
    return loc+1;
}
